import math
import random
import numpy as np
# import pandas as pd
import csv
import sklearn
import matplotlib.pyplot as plt

random.seed(134)


class phyloKRR:

    def __init__(self, kernel = 'rbf') -> None:

        # self.cov = cov
        self.kernel = kernel

        if self.kernel == 'rbf':
            self.params = {'gamma': 0.1, 'lambda': 0.1}

        else:
            self.params = {'c': 0.1, 'lambda': 0.1}

        # internal
        self.alpha = []
        self.X = []
        self.y = []

    def set_params(self, params):
        self.params = params

    def get_params(self):
        return self.params
    
    def fit(self, X, y):
        
        self.X = X
        self.y = y

        if self.kernel == 'rbf':
            K_train = self.RBF_kernel(self.X, self.X, self.params['gamma'])

        else:
            K_train = self.linear_kernel(self.X, self.X, self.params['c'])

        self.alpha = self.opt_alpha(K_train, self.y, self.params['lambda'])

    def predict(self, X_test):

        if not len(self.alpha):
            print('The model needs to fitted first')
            return None

        if self.kernel == 'rbf':
            K_test = self.RBF_kernel(X_test, self.X, self.params['gamma'])

        else:
            K_test = self.linear_kernel(X_test, self.X, self.params['c'])
        
        return K_test @ self.alpha
    
    def score(self, X_test, y_test, metric = 'rmse'):

        y_pred = self.predict(X_test)

        if metric == 'rmse':
            return np.sqrt( np.mean( (y_pred - y_test)**2 ) )
    
        else:
            # r2
            u = ((y_test - y_pred)**2).sum()
            v = ((y_test - y_test.mean())** 2).sum()

            return 1 - (u/v)

    def distance_matrix(self,a, b):
        """
        l2 norm squared matrix
        """
        return np.linalg.norm(a[:, None, :] - b[None, :, :], axis=-1)**2

    def RBF_kernel(self, a, b, gamma):
        """
        Radial Basis Function
        """        
        tmp_rbf = -gamma * self.distance_matrix(a, b)
        np.exp(tmp_rbf, tmp_rbf) # RBF kernel. Inplace exponentiation
        return tmp_rbf

    def linear_kernel(self, a, b, c):
        """
        Linear Kernel
        """
        XXt = a.dot(b.T)
        C = c * np.ones(XXt.shape)

        return XXt + C
    
    def P_mat(self, vcv, chol = False):

        if chol:
            P = np.linalg.cholesky( np.linalg.inv( vcv ) )

        else:
            Oinv = np.linalg.inv( vcv )
            L,Q  = np.linalg.eig( Oinv )
            P    = Q @ np.diag( np.sqrt( 1/L ) ) @ Q.T

        return P

    def rmse(self, K, alpha, Y):

        return np.sqrt( np.mean( (K.dot(alpha) - Y)**2 ) )
    
    def opt_alpha(self, K, y, reg_lam = None):
        # Y = y
        # X = X
        # m = None
        K_Idx = K + reg_lam * np.diag( np.ones( K.shape[0] ) )
        return np.linalg.inv( K_Idx ).dot( y )
    
def P_mat(vcv, chol = False, from_corr = True):
    # corr matrix
    if from_corr:
        Kr = np.diag(1/np.sqrt(np.diag(vcv)))
        vcv = Kr @ vcv @ Kr

    if chol:
        P = np.linalg.cholesky( np.linalg.inv( vcv ) )

    else:
        Oinv = np.linalg.inv( vcv )
        L,Q  = np.linalg.eig( Oinv )
        P    = Q @ np.diag( np.sqrt( 1/L ) ) @ Q.T

    return P

def P_mat_aug(spps, cov_file):
    # augmented matrix
    raw_data = []
    row_spps = []
    with open(cov_file, 'r') as f:
        for i in f.readlines()[1:]:
            line = i.strip().split(',')
            row_spps.append(line[0].replace('"', ''))
            raw_data.append( line[1:] )

    
    vcv = np.array(raw_data).astype(float)
    # vcv.shape

    idxs = [row_spps.index(i) for i in spps]
    row_aug = vcv[idxs,:]
    vcv_aug = row_aug[:,idxs]

    Oinv = np.linalg.inv( vcv_aug )
    L,Q  = np.linalg.eig( Oinv )
    P  = Q @ np.diag( np.sqrt( 1/L ) ) @ Q.T
    # L = np.linalg.cholesky( np.linalg.inv( vcv_aug ) )
    return P


def rmse(K, alpha, Y):
    return np.sqrt( np.mean( (K.dot(alpha) - Y)**2 ) )

def gls_error(X, y, pseudo_inv = False):

    if pseudo_inv:
        B_gls = np.linalg.pinv(X.T.dot(X)).dot(X.T.dot(y))

    else:
        B_gls = np.linalg.inv(X.T.dot(X)).dot(X.T.dot(y))

    return rmse(X, B_gls, y)

def standard_scale(u):
    return (u - np.mean(u, axis=0))/np.std( u, axis= 0)
# def standard_scale(u):
#     return (u - np.mean(u, axis=0))/np.std( u, axis= 0)


def cosine_similarity(a, b):
    # l2-normalization
    # a,b = np.array(train_error_rbf[0:2]), np.array(test_error_rbf[0:2])
    if isinstance(a, list):
        a = np.array(a)
    
    if isinstance(b, list):
        b = np.array(b)

    deno = np.linalg.norm(a,2)*np.linalg.norm(b,2)
    return (a.T @ b)/deno

def getIndex(window,
             reg_lambdas,
             training_errors, 
             testing_errors):
    
    # window = 5
    tol = 0.01

    best_sim = 0
    best_index = None
    for i in range(0, len(reg_lambdas), window):

        cos_sim = cosine_similarity(
            training_errors[ i:i+window ],
            testing_errors[  i:i+window ]
        )

        if cos_sim > best_sim:
            if abs(cos_sim - best_sim) <= tol:
                best_index = i
                break
            
            else:
                best_sim = cos_sim
                best_index = i

    return best_index

def split_data(X,y,num_test):
    n,_ = X.shape

    test_idx  = random.sample(range(n), k = num_test)
    train_idx = list( set(range(n)) - set(test_idx) )

    X_train, X_test = X[train_idx,:], X[test_idx,:]
    y_train, y_test = y[train_idx]  , y[test_idx]

    return X_train,y_train, X_test, y_test

def dat_prep(one_file, P, standarize = True, cat_cols = [2]):
    """
    standarization is performed on columns that are not
    categorical colums
    """
    # one_file = './primateEyesv2.csv'
    data = np.loadtxt(one_file, delimiter=',')
    # data = np.c_[np.ones(n),data]
    X0,y0 = data[:,:-1], data[:,-1]

    if standarize:
        num_cols = list( 
            set(range(X0.shape[1])) - set(cat_cols) 
        )
        # scale only num values
        X0[:,num_cols] = standard_scale(X0[:,num_cols])

    # X0[:,1:] = standard_scale( X0[:,1:] )
    # y0 = standard_scale( y0 )
    X = P.dot( X0 )
    y = P.dot( y0 )

    return X, y

def k_folds(X, folds = 3):
    """
    test_indx, train_indx
    """
    # X = X_train
    # folds = 4
    
    n,_ = X.shape
    all_index = list(range(n))
    random.shuffle(all_index)

    window = n/folds

    k_folds = []

    i = 0
    while True:

        init_indx = i
        end_indx  = i + window

        test_indx = all_index[round(init_indx):round(end_indx)]
        train_indx = list(set(all_index) - set(test_indx))
        # print(init_indx, end_indx)
        k_folds.append([test_indx, train_indx])

        i += window
        if i >= n:
            break

    # len(k_folds)
    return k_folds

def evaluate_folds(X, y, myFolds, model, tmp_params):

    # print(kwargs)
    # kwargs = {'c': 0.4, 'lambda': 0.1}
    # params = {'gamma': 0.4, 'lambda': 0.1}
    # params = tmp_params
    # model = phyloKRR(kernel='rbf')

    model.set_params(tmp_params)
    # model.get_params()

    all_errs = []
    for test_indx, train_indx in myFolds:
        # print(len(test_indx), len(train_indx))
        X_train,y_train = X[train_indx,:], y[train_indx]
        X_test,y_test = X[test_indx,:], y[test_indx]

        model.fit(X_train, y_train)

        # print(np.var(X_train))
        # print(np.var(model.X))
        # print(np.var(model.alpha))

        tmp_err = model.score(X_test, y_test, metric = 'rmse')
        all_errs.append(tmp_err)

    # return np.mean(all_errs)
    return np.median(all_errs)

def k_fold_cv_grid(X, y, model, params, folds = 3, give_vals = False):
    # folds = 3\
    # X,y = X_train, y_train
    # params = params_linear
    # linear =True

    if model.kernel == 'rbf':
        b = 'gamma'
    else:
        b = 'c'

    a = 'lambda'
        
    n_a = len(params[a])
    n_b = len(params[b])

    A,B = np.meshgrid(params[a], params[b])
    C = np.zeros((n_a, n_b))

    # C.shape
    df = []
    myFolds = k_folds(X,folds)
    for i in range(n_a):
        for j in range(n_b):
            tmp_params = {a: A[i,j], b: B[i,j] }
            C[i,j] = evaluate_folds(X, y, myFolds, model, tmp_params)
            
            if give_vals:
                df.append( [A[i,j], B[i,j], C[i,j]] )

    # C.shape
    print(C[ C ==  C.min()][0])
    best_pars = {a: A[ C ==  C.min()][0], b: B[ C ==  C.min()][0]}

    # print(C[ C ==  C.max()][0])
    # best_pars = {a: A[ C ==  C.min()][0], b: B[ C ==  C.max()][0]}

    if not give_vals:
        return best_pars
    
    else:
        return best_pars, df
    
    # fig,ax=plt.subplots(1,1)
    # cp = ax.contourf(np.log(A),np.log(B),np.log(C))
    # fig.colorbar(cp) # Add a colorbar to a plot
    # # ax.set_title('GA solution for the 2D Schwefel\n function after 1 generation')
    # ax.set_xlabel(r'$\lambda$')
    # ax.set_ylabel(r'$\gamma$')

def k_fold_cv_random(X, y, 
                     model, 
                     params,
                     folds = 3, 
                     sample = 500):
    # X = X_train
    # y = y_train
    # folds = 4
    
    all_params = params.keys()
    tested_params = np.ones((sample, len(all_params)))
    for n,k in enumerate(all_params):
        tested_params[:,n] = np.random.choice(params[k], sample)
    
    all_errors = []
    myFolds = k_folds(X, folds)
    for vec in tested_params:
        # vec
        tmp_params = dict(zip(all_params, vec))
        tmp_err = evaluate_folds(X, y, 
                                 myFolds,
                                 model, 
                                 tmp_params)
        all_errors.append([tmp_params, tmp_err])

    best_ = sorted(all_errors, key=lambda kv: kv[1], reverse=False)[0]
    print("best score: ", best_[1])
    
    return best_[0]

def gls_errors(X, y, pseudo_inv = False):

    if pseudo_inv:
        B_gls = np.linalg.pinv(X.T.dot(X)).dot(X.T.dot(y))

    else:
        B_gls = np.linalg.inv(X.T.dot(X)).dot(X.T.dot(y))

    return X.dot(B_gls) - y

def test_normality_linear(X, y, pseudo_inv = False):
    from scipy import stats

    errors = gls_errors(X, y, pseudo_inv=pseudo_inv).flatten()
    res = stats.normaltest(errors)
    return res.pvalue,errors

def standard_scale(u):
    return (u - np.mean(u, axis=0))/np.std( u, axis= 0)

def get_err_pval(X, y, pseudo_inv =  False, bins = 30, plot = False):

    pval,errors = test_normality_linear(X, y, pseudo_inv = pseudo_inv)

    if plot:
        fig, ax = plt.subplots()
        # the histogram of the data
        ax.hist(errors, bins, density=True)
        ax.set_title('p-value = %s' % pval)
        plt.show()

    return pval

# from sklearn import kernel_ridge
# KernelRidge

import glob
covs = glob.glob('./simulations/rcoal_*.csv')


params = {
    'lambda' : np.logspace(-5, 15, 100, dtype = float,base=2),
    # 'gamma' : np.logspace(-15, -5, 200, dtype = float,base=2),
    'gamma' : np.logspace(-15, 3, 100, dtype = float,base=2),

    # 'gamma' : np.logspace(-25, 0, 100, dtype = float, base=2),
    # 'lambda' : np.logspace(-15, 0, 100, dtype = float,base=2),    
}

params_linear = {
    'c' : np.logspace(-5, 15, 100, dtype = float,base=2),
    'lambda' : np.logspace(-5, 15, 100, dtype = float,base=2)
}

rbf_model = phyloKRR(kernel='rbf')
linear_model = phyloKRR(kernel='linear')


n_spps = 400
mean_vector = np.zeros(n_spps)

all_errors_sim = []

for cov_file in covs:
    # cov_file
    vcv = np.loadtxt(cov_file, delimiter = ",")
    num_test = round(vcv.shape[0]*0.40)
    P = P_mat(vcv, chol= False, from_corr =  not False)

    # L,Q  = np.linalg.eig( vcv )
    # P_inv    = Q @ np.diag( np.sqrt( L ) ) @ Q.T
    for b in [-2,-1,0,1,2,3,4,5]:
        # b = 4
        X1 =  np.random.multivariate_normal(
            mean=mean_vector, 
            cov=vcv,
            # cov=np.diag(np.ones(n_spps)),
            )
            
        X2 =  np.random.multivariate_normal(
            mean=mean_vector, 
            cov=vcv,
            # cov=np.diag(np.ones(n_spps)),
            )

        X = np.c_[X1, X2]
        # X = X - np.min(X) + 1.5
        # y = ((X[:,0]**b) * X[:,1]) + ((X[:,1]**b) * X[:,0])
        y = (X[:,0] + X[:,1])**b

        X = P @ X
        y = P @ y
        # get_err_pval(P @X, P@y, bins = 20, pseudo_inv=True)

        X_train, y_train, X_test, y_test = split_data(X, y, num_test)
        # X_train.shape
        params_grid_rbf = k_fold_cv_random(X_train,y_train,
                                        rbf_model,
                                        params,
                                        folds=3,
                                        sample=100)
        
        # params_grid_rbf = {'lambda': 0.10213453767217533, 'gamma': 0.00007}
        rbf_model.set_params(params_grid_rbf)
        rbf_model.fit(X_train, y_train)
        rbfk_err = rbf_model.score(X_test, y_test, metric='rmse')


        params_grid_linear = k_fold_cv_random(X_train,y_train,
                                            linear_model,
                                            params_linear,
                                            folds=3,
                                            sample=100)
        
        linear_model.set_params(params_grid_linear)
        linear_model.fit(X_train, y_train)
        link_err = linear_model.score(X_test, y_test, metric = 'rmse')

        X_test = np.c_[np.ones(X_test.shape[0]), X_test]
        lin_err = gls_error(X_test, y_test, False)

        errors_sim = [
            b,
            rbfk_err,
           link_err,
           lin_err
        ]
        print(errors_sim)
        all_errors_sim.append(errors_sim)

with open('sim_errors_v4.csv', 'w') as f:
    csv_writer = csv.writer(f)
    csv_writer.writerows(all_errors_sim)




        # import matplotlib.pyplot as plt
        # b = 0 # -3,  0
        # # z = ((X[:,0]**b)*X[:,1] + (X[:,1]**b)*X[:,0]).reshape(-1,1)

        # z = np.zeros((n_spps, n_spps))
        # xx1,xx2 = np.meshgrid(X[:,0],X[:,1])
        # for i in range(n_spps):
        #     for j in range(n_spps):
        #             # i,j
        #             z[i,j] =  ((xx1[i,j]**b) * xx2[i,j]) + ((xx2[i,j]**b) * xx1[i,j])
        #             # if z[i,j] > 4:
        #             #     print(xx1[i,j])

        # r = np.round(z,2)
    # fig = plt.figure()
    # # Add an axes
    # ax = fig.add_subplot(111,projection='3d')
    # # plot the surface
    # # ax.plot_wireframe( xx1,xx2,r,alpha=0.5, rcount =20, ccount = 20)
    # ax.scatter( X[:,0], X[:,1],y)
    # # fig,ax=plt.subplots(1,1)
    # # cp = ax.contourf(xx1,xx2, z)
    # # ax.view_init(0, 10)
    # # ax.view_init(0, 40)
    # plt.show()